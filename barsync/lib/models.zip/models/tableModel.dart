import 'package:cloud_firestore/cloud_firestore.dart';

class TableModel {
  String id;
  int number;
  int dinners;
  String state;
  Map<String, double> location;
  DocumentReference idRestaurant;
  DocumentReference? waiter;

  TableModel({
    this.id = '',
    required this.number,
    this.dinners = 0,
    this.state = '',
    this.location = const {},
    required this.idRestaurant,
    this.waiter,
  });

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'number': number,
      'dinners': dinners,
      'state': state,
      'location': location,
      'restaurant': idRestaurant,
      'waiter': waiter,
    };
  }

  factory TableModel.fromJson(Map<String, dynamic> json) {
    final loc =
        (json['location'] as Map<String, dynamic>?)?.map(
          (k, v) => MapEntry(k, (v as num).toDouble()),
        ) ??
        {};
    return TableModel(
      id: json['id'] ?? '',
      number: json['number'] ?? 0,
      dinners: json['dinners'] ?? 0,
      state: json['state'] ?? '',
      location: loc,
      idRestaurant: json['restaurant'],
      waiter: json['waiter'],
    );
  }
}
